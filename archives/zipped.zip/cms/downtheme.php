<?php
include_once $_SERVER['DOCUMENT_ROOT']."/cms/cms.php";
$NO_ECHO=true;
include_once $_SERVER['DOCUMENT_ROOT']."/cms/auf.php";
if($t!=false){
CMS::antiXSS_H();
CMS::antiXSS_R();
$_GET['theme']=substr($_GET['theme'], 17, -2);
$_GET['theme']=preg_replace("@[^a-zA-Z1-90_\-\.]@", '', $_GET['theme']);
$_GET['theme']=preg_replace("@\.\.+@", '', $_GET['theme']);
$_GET['theme']=explode(".", $_GET['theme']);
$_GET['theme']=$_GET['theme'][0].".".$_GET['theme'][1];
header("Content-type: application/octet-stream;");
header('Content-Disposition: attachment;filename="'.$_GET['theme'].'"');
readfile("themes/".$_GET['theme']);
}
?>
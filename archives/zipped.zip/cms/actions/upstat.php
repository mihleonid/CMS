<ACTION>
<?php
if(\LCMS\Core\Users\Stats::can($auf[2], "status")){
	$res=CMS::levelUpStatus($_POST['ststu']);
	if($res!= CMS::OK){
		$exit=false;
		$error=$res;
	}
}
?>
</ACTION>
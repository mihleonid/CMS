<CACHE />
<PRE>
timezone
</PRE>
<HEADER>
Временная зона
</HEADER>
<FORM>
<form action="action.php" method="POST">
|Header|
<input type="text" name="path" value="$PARAM$new$" style="" placeholder="Зона" pattern=".+/.+" required>
<input type="submit" value="Настроить">
</form>
</FORM>
<ACTION>
<?php
return \LCMS\Core\Enviroment\Timezone::set($_POST['path']);
?>
</ACTION>
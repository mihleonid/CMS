<CACHE />
<PRE>
clever
</PRE>
<HEADER>
Назначить себя $PARAM$ne$продвинутым пользователем
</HEADER>
<FORM>
<form action="action.php" method="POST">
|Header|
<img onclick="this.parentNode.submit();" style="cursor: pointer;" src="/cms/pic/$PARAM$d$.png" ></img>
</form>
</FORM>
<ACTION>
<?php
return \LCMS\Core\Users\Users::replaceClever();
?>
</ACTION>
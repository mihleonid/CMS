<CACHE />
<PRE>
accclear
</PRE>
<HEADER>
Очистить защитный счётчик
</HEADER>
<FORM>
<form action="action.php" method="POST">
|Header|
<input type="submit" value="Сменить">
</form>
</FORM>
<ACTION>
<?php
return \LCMS\Core\Security\Counter::clear();
?>
</ACTION>
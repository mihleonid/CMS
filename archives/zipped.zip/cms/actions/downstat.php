<?php
if(\LCMS\Core\Users\Stats::can($auf[2], "status")){
	$res=CMS::levelDownStatus($_POST['ststu']);
	if($res!= CMS::OK){
		$exit=false;
		$error=$res;
	}
}
?>
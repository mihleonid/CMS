<PRE>
defpatt
</PRE>
<HEADER>
Настроить шаблон по умолчанию (должен быть доступен всем)
</HEADER>
<FORM>
<form action="action.php" method="POST">
|Header|
Шаблон:<?php
$string= \LCMS\Core\Patterns\Pattern::getAll(false);
echo($string[1]);
?>
<br>
<input type="submit" value="Настроить">
</form>
</FORM>
<ACTION>
<?php
return \LCMS\Core\Patterns\Pattern::setDefault($_POST['s']);
?>
</ACTION>
<PRE>
pagedel
</PRE>
<FORM>
|F|
<input type="hidden" name="path" value="$PARAM$all$" required>
<input type="submit" value="Удалить">
</form>
</FORM>
<ACTION>
<?php
$path= \LCMS\Core\Pages\Page::clearPath($_POST['path']);
if(file_exists($_SERVER['DOCUMENT_ROOT'].$path) and is_file($_SERVER['DOCUMENT_ROOT'].$path)){
	unlink($_SERVER['DOCUMENT_ROOT'].$path);
	\LCMS\Core\Pages\PageLog::action($path, $GLOBALS['AUTH'][0], \LCMS\Core\Pages\PageLog::DELETE);
}else{
	\LCMS\Core\Pages\PageLog::action($path, $GLOBALS['AUTH'][0], \LCMS\Core\Pages\PageLog::DELETE, false);
	return new Result("Удаляемая страница не найдена");
}
?>
</ACTION>
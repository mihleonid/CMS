<PRE>
archive
</PRE>
<HEADER>
Создать архив
</HEADER>
<FORM>
<form action="action.php" method="POST">
|SHeader|
<input type="hidden" name="tsel" value="archive">
<input type="hidden" name="page" value="archive.php?<?php echo(((isset($_SERVER['argv'][0]))?($_SERVER['argv'][0]):(""))); ?>">
Имя архива:<input type="text" name="name" placeholder="Имя" pattern="[a-zA-Z1-90\.]+">
<?php
include('cmsTree.php');
?>
<input type="submit" value="Создать">
<div>
<?php
$globtext=file_get_contents("cmsTree.php");
function html_my_folderc($udir){
	$udir=rtrim(str_replace("\\", "/", $udir));
	if(is_file($udir)){
		return(array($udir));
	}elseif(is_dir($udir)){
		$text=array($udir);
		$dir=dir($udir);
		while(false!==($entry=$dir->read())){
			if(($entry!=".")and($entry!="..")){
				$text=array_merge(html_my_folderc($udir."/".$entry), $text);
			}
		}
		return $text;
	}
}
$return='';
foreach(html_my_folderc((isset($FOLDER_TO_TREE))?($FOLDER_TO_TREE):('..')) as $r){
	if((strpos($globtext, $r)===false)and(strpos($r, 'cms/')!==false)and(strpos($r, 'cms/bg')===false)and(strpos($r, 'cms/gallery')===false)and(strpos($r, 'cms/s')===false)and(strpos($r, 'cms/actions')===false)and(strpos($r, 'cms/pic')===false)and(strpos($r, 'cms/pluginrepos')===false)and(strpos($r, 'cms/pluginscripts')===false)and(strpos($r, 'cms/themes')===false)and(strpos($r, 'cms/mane')===false)and(strpos($r, 'cms/tmp')===false)and(strpos($r, 'cms/moduls/themes')===false)and(strpos($r, 'cms/moduls/plugins')===false)and(strpos($r, 'cms/parts')===false)and(strpos($r, 'cms/moduls/parts')===false)and(strpos($r, 'cms/moduls/script')===false)and(strpos($r, 'cms/moduls/patterns')===false)and(strpos($r, 'cms/moduls/patpack')===false)){
		$return.=('<br><big style="color: red;">'.$r."</big>");
	}
}
if($return!=""){
	echo "Отсутствуют в списке:";
	echo($return);
	echo '<br><a href="etl.php">Список не пуст</a>';
}
?>
</div>
</form>
</FORM>
<ACTION>
<?php
include_once("LArchiver.php");
$ar=new LArchiver();
foreach($_POST['filesi'] as $k=>$l){
	$ar->add($l, substr($l, 2));
	// echo($l."}".substr($l, 2)."<br>");
}
function filess($path){
	$objects = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path), RecursiveIteratorIterator::SELF_FIRST);
	$r=array();
	foreach($objects as $name => $object){
		$r[]=str_replace("\\", "/", $name);
	}
	return $r;
}
if(isset($_POST['add']['SITE'])){
	foreach(filess('..') as $r){
		if((strpos($r, '../cms')===false)and(strpos($r, '../archives')===false)){
			$ar->add($r, substr($r, 2));
			// echo($r."}".substr($r, 2)."<br>");
		}
	}
}
$ar->write("../archives/".$_POST['name']);
unset($ar);
// $exit=false;
?>
</ACTION>
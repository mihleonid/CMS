<?php
if(\LCMS\Core\Users\Stats::can($auf[2], "pagedel")){
$path=PAGE_PATH_CLEAR($_POST['path'], $auf[2], $auf[0]);
$path=substr($path, 0, strlen($path)-4);
if(file_exists($_SERVER['DOCUMENT_ROOT'].$path) and is_dir($_SERVER['DOCUMENT_ROOT'].$path)){
	$di = new RecursiveDirectoryIterator($_SERVER['DOCUMENT_ROOT'].$path, FilesystemIterator::SKIP_DOTS);
	$ri = new RecursiveIteratorIterator($di, RecursiveIteratorIterator::CHILD_FIRST);
	foreach ( $ri as $file ) {
		$file->isDir() ?  rmdir($file) : unlink($file);
	}
	rmdir($_SERVER['DOCUMENT_ROOT'].$path);
	CMS::actionPageLog($path, $auf[0], CMS::PAGE_DELETE);
}else{
	CMS::actionPageLog($path, $auf[0], CMS::PAGE_DELETE, false);
	$error="Удаляемая папка не найдена";
	$exit=false;
}
}
?>
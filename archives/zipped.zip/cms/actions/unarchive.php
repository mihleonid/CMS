<PRE>
unarchive
</PRE>
<HEADER>
Разархивировать и применить
</HEADER>
<FORM>
<form action="action.php" method="POST" autocomplete="off">
|SHeader|
<input type="hidden" name="tsel" value="unarchive">
<input type="hidden" name="page" value="archive.php?<?php echo(((isset($_SERVER['argv'][0]))?($_SERVER['argv'][0]):(""))); ?>">
Имя архива:
<select name="pack" required>
<?php
$htm="";
$dir=dir("../archives/");
while(false!==($entry=$dir->read())){
	if(($entry!=".")and($entry!="..")){
		$entry=substr($entry, 0, strlen($entry)-5);
		$htm.="<option value=\"$entry\">$entry</option>";
	}
}
echo($htm);?>
</select>
<br>
Действия при одинаковом имени:
<div>
<input type="radio" name="zamena" value="up" checked>Заменить
<input type="radio" name="zamena" value="down">Не распаковывать
</div>
<input type="submit" value="Разархивировать">
</form>
</FORM>
<ACTION>
<?php
if(\LCMS\Core\Users\Stats::can($auf[2], "unarchive")){
	$res=CMS::Unarchive($_POST['pack'], $_POST['zamena']);
	if($res!= CMS::OK){
		$exit=false;
		$error=$res;
	}
}
?>
</ACTION>
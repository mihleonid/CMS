<PRE>
category
</PRE>
<FORM>
|F|
<input type="hidden" name="kat" value="$PARAM$all$">
<input type="submit" value="Удалить">
</form>
</FORM>
<ACTION>
<?php
return \LCMS\Core\Pages\Category::delete($_POST['kat']);
?>
</ACTION>
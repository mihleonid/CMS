<CLEVER />
<PRE>
cmspatt
</PRE>
<HEADER>
Настроить шаблон cms
</HEADER>
<FORM>
<form action="action.php" method="POST">
|Header|
Шаблон:<?php
$string=\LCMS\Core\Patterns\Pattern::getAll();
echo($string[1]);
?>
<br>
<input type="submit" value="Настроить">
</form>
</FORM>
<ACTION>
<?php
return \LCMS\Core\Patterns\Pattern::setCMS($_POST['s']);
?>
</ACTION>
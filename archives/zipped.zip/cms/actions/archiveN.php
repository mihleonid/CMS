<DOWNLOAD />
<CLEVER />
<PRE>
archive
</PRE>
<HEADER>
Создать архив низкого уровня
</HEADER>
<FORM>
<form action="action.php" method="POST" autocomplete="off">
|SHeader|
<input type="hidden" name="tsel" value="archiveN">
<input type="hidden" name="page" value="/cms/archive.php?<?php echo(((isset($_SERVER['argv'][0]))?($_SERVER['argv'][0]):(""))); ?>">
<div><input type="checkbox" name="download" value="1" style="vertical-align: middle;" /><span style="vertical-align: middle;">Скачать</span></div>
Имя архива:<input type="text" name="name" placeholder="Имя" pattern="[a-zA-Z1-90_]+">
<?php
$PHP_SCRIPT=true;
include('TreeFolderSelector.php');
?>
<input type="submit" value="Создать">
</form>
</FORM>
<ACTION>
<?php
$file = $_SERVER['DOCUMENT_ROOT']."/cms/tmp/archive".time().mt_rand()."e.zip";
$zip = new ZipArchive();
$zip->open($file, ZipArchive::CREATE);
$zip->addFile($_SERVER['DOCUMENT_ROOT'].'/.htaccess', '.htaccess');
foreach($_POST['filesi'] as $name){
	if($name==".."){
		continue;
	}
	$name=substr($name, 2);
	if(is_file($_SERVER['DOCUMENT_ROOT'].$name)){
		$zip->addFile($_SERVER['DOCUMENT_ROOT'].$name, substr($name, 1));
	}
}
$zip->close();
$_POST['name']=preg_replace('@[^a-zA-Z1-90_]@', '', $_POST['name']);
if(isset($_POST['download'])){
	header("Content-Type: application/zip");
	header("Content-Length: ".filesize($file));
	header("Content-Disposition: attachment; filename=\"".$_POST['name'].".zip\"");
	readfile($file);
	unlink($file);
}else{
	rename($file, $_SERVER['DOCUMENT_ROOT']."/archives/".$_POST['name'].".zip");
}
?>
</ACTION>
<PRE>
env
</PRE>
<FORM>
|F|
<input type="hidden" name="k" value="$PARAM$all$">
<input type="submit" value="---delete---">
</form>
</FORM>
<ACTION>
<?php
//print_r($_POST);
//exit;
return \LCMS\Core\Enviroment\Loc::delete($_POST['k']);
?>
</ACTION>
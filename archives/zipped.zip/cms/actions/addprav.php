<PRE>
status
</PRE>
<FORM>
<form action="action.php" method="POST" autocomplete="off">
|Header|
<table>
<tr>
<td>Право:</td>
<td><input type="text" placeholder="Название" name="stat" style="width: 100%;" pattern="[a-zA-Z_\-=\+\*1-90]+" required></td>
</tr>
<tr>
<td>Группа:</td>
<td><?php echo($PARAM$alltext$); ?></td>
</tr>
<tr>
<td>Русское название:</td>
<td><input type="text" placeholder="Название" name="ops" style="width: 100%;min-widh: 200px;" pattern="[a-zA-Z_\-=\+\*1-90а-яЁёЩшШшЬьЪъА-Я ]+" required></td>
</tr>
<tr>
<td colspan="2"><input type="submit" value="Добавить" style="width: 100%;"></td>
</tr>
</table>
</form>
</FORM>
<ACTION>
<?php
return \LCMS\Core\Users\Pravs::add($_POST['stat'], $_POST['group'], $_POST['ops']);
?>
</ACTION>
<CACHE />
<PRE>
version
</PRE>
<HEADER>
Версия
</HEADER>
<FORM>
<p><small>Без повода изменять не рекомендуется.</small></p>
<form action="action.php" method="POST">
|Header|
<input type="text" name="path" value="$PARAM$new$" style="" placeholder="Версия" pattern=".+\..+\..+\..+" required>
<input type="submit" value="Настроить">
</form>
</FORM>
<ACTION>
<?php
return \LCMS\Core\Enviroment\CMSEnv::changeVersion($_POST['path']);
?>
</ACTION>
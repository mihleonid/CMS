<PRE>
archive
</PRE>
<HEADER>
Удалить архив
</HEADER>
<FORM>
<form action="action.php" method="POST" autocomplete="off">
|SHeader|
<input type="hidden" name="tsel" value="delarchive">
<input type="hidden" name="page" value="archive.php?<?php echo(((isset($_SERVER['argv'][0]))?($_SERVER['argv'][0]):(""))); ?>">
Имя архива:
<select name="pack" required>
<?php
$dir=dir("../archives/");
$htm="";
while(false!==($entry=$dir->read())){
	if(($entry!=".")and($entry!="..")){
		$htm.="<option value=\"$entry\">$entry</option>";
	}
}
echo($htm);?>
</select>
<br>
<input type="submit" value="---delete---">
</form>
</FORM>
<ACTION>
<?php
return \LCMS\Core\Archiver\Archiver::Gdelete($_POST['pack']);
?>
</ACTION>
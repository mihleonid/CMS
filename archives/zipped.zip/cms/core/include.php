<?php
include_once(__DIR__ ."/cmsphp.php");
include_once(__DIR__ ."/enviroment.php");
include_once(__DIR__ ."/actions.php");
include_once(__DIR__ ."/archiver.php");
include_once(__DIR__ ."/gui.php");
include_once(__DIR__ ."/io.php");
include_once(__DIR__ ."/modules.php");
include_once(__DIR__ ."/pages.php");
include_once(__DIR__ ."/patterns.php");
include_once(__DIR__ ."/security.php");
include_once(__DIR__ ."/users.php");
?>
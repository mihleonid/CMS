<?php
namespace LCMS\Core\Archiver{
	use \LCMS\Core\Enviroment\Loc;
	use \LCMS\Core\Actions\Result;
	class Compressor{
		public static function compress($str, $level=9){
			if(function_exists("gzdeflate")){
				$compressed=gzdeflate($str, $level);
				return "{".$compressed."}";
			}
			return "|".$str."}";
		}
		public static function uncompress($str){
			$str=trim($str);
			$str=substr($str, 0, strlen($str)-1);
			$ch=$str[0];
			$str=substr($str, 1);
			if($ch=="{"){
				return gzinflate($str);
			}else{
				return $str;
			}
		}
	}
	class Archiver{
		private $files;
		public static function GarchiveN($files, $name){
			$name=preg_replace("@^[a-zA-Z1-90_]@", "", $name);
			$ar=new Archiver();
			foreach($files as $l){
				$ar->add($l, substr($l, 2));
			}
			$ar->archive($_SERVER['DOCUMENT_ROOT']."/archives/".$name.".lbgz");
			unset($ar);
			return new Result();
		}
		public static function GUnarchive($archive, $zamena){
			$archive=str_replace("..", "", $archive);
			if(file_exists($archive)){
				if(($zamena=="down")or($zamena==false)){
					$zamena=false;
				}else{
					$zamena=true;
				}
				$ar=new Archiver();
				$ar->unarchive($_SERVER['DOCUMENT_ROOT']."/archives/$archive.lbgz", $_SERVER['DOCUMENT_ROOT'], $zamena);
				return new Result();
			}else{
				return new Result("������ �� ����������");
			}
		}
		public static function Gdelete($archive){
			$archive=str_replace('..', '', $archive);
			if(file_exists($archive)){
				unlink($_SERVER['DOCUMENT_ROOT']."/archives/$archive");
			}
			return new Result();
		}
		private function __construct(){}
		private function add($file){
			$a=(new \SplFileInfo($file));
			$a=($a->getRealPath());
			if($a!=false){
				$this->files[substr($a, strlen($_SERVER['DOCUMENT_ROOT']))]=$a;
			}
		}
		private function archive($fn){
			$fh=fopen($fn, "wb+");
			fwrite($fh, "\0x1");
			foreach($this->files as $k=>$name){
				$content=Compressor::compress(file_get_contents($name));
				$content=$k.">".strlen($content).">".$content.">";
				fwrite($fh, $content);
			}
			fclose($fh);
		}
		private function unarchive($path, $dir, $zamena){
			$fh=fopen($path, "rb");
			if(fread($fh, 1)=="\0x1"){
				$sost=0;
				$file="";
				$ost=0;
				$oost="";
				$filename="";
				while(!feof($fh)){
					$a=fread($fh, 1);
					if($a!=">"){
						switch($sost){
							case 0:
								$filename.=$a;
								break;
							case 1:
								$oost.=$a;
								break;
							case 2:
								$file.=$a;
								break;
						}
					}else{
						if($sost!=2){
							$sost++;
							if($sost==2){
								$ost=(int)$oost;
							}
							if($sost==3){
								$sost=0;
							}
						}else{
							if($ost<=0){
								file_put_contents($filename, Compressor::uncompress($file));
							}
						}
					}
				}
			}
		}
	}
}
?>
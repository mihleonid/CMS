[DATA_BASE_ERROR] base: tables.tdb STAT_CAN_BASE; name: admin"obnov",  in:15:41:52&nbsp;01.08.2018
[DATA_BASE_ERROR] base: tables.tdb STAT_CAN_BASE; name: admin"obnov",  in:15:42:08&nbsp;01.08.2018
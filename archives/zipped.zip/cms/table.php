<?php
include_once $_SERVER['DOCUMENT_ROOT']."/cms/cmsinclude.php";
use \LCMS\Core\Pages\Page;
use \LCMS\Core\Actions\Form;
use \LCMS\Core\Actions\Action;
use \LCMS\Core\Users\Users;
use \LCMS\Core\Users\Stats;
Page::CMS();
txt('<a href="admin.php"><img src="/cms/pic/main.png" title="Главная" />---back---</a>');
if(Stats::can('status')){
Action::e("stat");
?>
<form action="action.php" style="display: none;" id="hid" method="POST">
<?php
echo(Form::Sheader());
?>
<input type="hidden" name="tsel" id="hidoa" value="stat">
<input type="hidden" name="ststu" id="hido" value="">
<input type="hidden" name="page" value="table.php">
</form>
<table style="margin-top: 4px;">
<tr><th colspan="4">Управление статусами</th></tr>
<tr><th>Статус</th><th>Русское название статуса</th><th>Изменение</th><th>Удалить</th></tr>
<?php
$mydb=new \LCMS\MainModules\D_BASE($_SERVER['DOCUMENT_ROOT']."/cms/tablei.tdb");
$myall=$mydb->get_all();
foreach($myall as $keym=>$linem){
	$ism=new Action("edittextstat", array('keym'=>($keym), 'linem'=>($linem)));
	echo("<tr><td>$keym</td><td>$linem</td><td style=\"width: max-content;\">$ism</td><td>");
	Action::e("delstat", $keym);
	echo("</td></tr>");
}
?>
</table>
<?php
echo(new Action("addstat"));
if((Users::isClever())){
?>
Отладка: 
<a href="prav.php">Управление правами</a>
<?php }?>
<?php
}
Page::footer();?>
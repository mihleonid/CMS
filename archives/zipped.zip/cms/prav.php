<?php
include_once $_SERVER['DOCUMENT_ROOT']."/cms/cmsinclude.php";
use \LCMS\Core\Pages\Page;
use \LCMS\Core\Actions\Form;
use \LCMS\Core\Actions\Action;
use \LCMS\Core\Users\Users;
use \LCMS\Core\Users\Stats;
use \LCMS\MainModules\D_BASE;
Page::CMS();?>
<a href="table.php">Назад</a>
<?php if(trim($GLOBALS['AUTH'][2])=="globaladmin"){ #todo do?>
<h3>Управление правами</h3>
<table style="width: -webkit-fill-available;">
<tr><th>Право</th><th>Русское название права</th><th>Изменение</th><th>Удаление</th></tr>
<?php
$mydb=new D_BASE($_SERVER['DOCUMENT_ROOT']."/cms/tablesi.tdb");
$dbt=new D_BASE($_SERVER['DOCUMENT_ROOT']."/cms/tablegroup.tdb");
$myall=$mydb->get_all();
$allt=$dbt->get_all();
$alltext="<select name=\"group\">";
$alltext.="<option value=\"_NOGROUP\">&lt;Без категории&gt;</option>";
foreach($allt as $laal){
	$alltext.="<option value=\"".$laal[0]."\">".$laal[1]."</option>";
}
$alltext.="</select>";
function alltext($r, $allt){
	$aalltext="<select name=\"group\">";
	$aalltext.="<option value=\"_NOGROUP\">&lt;Без категории&gt;</option>";
	foreach($allt as $laal){
		$aalltext.="<option value=\"".$laal[0]."\"".(($r[1]==$laal[0])?(' selected'):('')).">".$laal[1]."</option>";
	}
	$aalltext.="</select>";
	return $aalltext;
}
foreach($myall as $keym=>$linem){
$at=alltext($linem, $allt);
$ism=new Action("edittextprav", array('at'=>$at, 'keym'=>$keym, 'linem0'=>$linem[0])).'
</td><td style="padding-right: 40px;">
'. new Action("delprav", array('keym'=>$keym));
	echo("<tr><td>$keym</td><td>".$linem[0]."</td><td style=\"width: max-content;\">$ism</td></tr>");
}
?>
</table>
<a href="pravgroup.php">Изменение групп</a>
<h3>Добавить право</h3>
<?php
echo(new Action('addprav', array('alltext'=>'"'.addslashes($alltext).'"')));
?>
<?php
}
Page::footer();
?>
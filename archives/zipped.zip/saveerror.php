<?php
file_put_contents($_POST['file'], str_replace("\n", "\r\n", base64_decode($_POST['text'])));
// file_put_contents("output", str_replace("\n", "\r\n", base64_decode($_POST['text'])));
// echo( /*html_entity_decode*/urldecode(base64_decode($_POST['text'])));
// file_put_contents("output", str_replace("\n", "\r\n", urldecode(base64_decode($_POST['text']))));
?>
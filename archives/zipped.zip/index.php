<?php
/*PATTERN*/
$s="<default>";
/*DATASET*/
$DATA="";
$USER="admin";
include_once $_SERVER['DOCUMENT_ROOT']."/cms/cmsinclude.php";
\LCMS\Core\Pages\Page::Site($s, $USER, $DATA);
/*START_CONTENTS*/ ?>
<h3 style="text-align: center;"><font size="1"><span style="font-size: 16pt;">Это -&nbsp;<u>главная страница</u> <i>сайта</i> сделанного с помощью</span></font> <font size="1" face="Arial Black"><span style="font-size: 16pt; background-color: rgba(100, 100, 255, 0.725);">CMS Leonid</span></font></h3><div style="text-align: center;"><font size="1" face="Arial Black"><span style="font-size: 16pt;"><span style="background-color: rgba(100, 100, 255, 0);"><img src="http://www.site/cms/gallery/cmsleonid.png"></span><br></span></font></div>